import http.server
import ssl
import socket
import signal
import sys

server_address = 'localhost'
server_port = 8443
address_family = socket.AF_INET

# 創建 SSL context
ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ssl_context.load_cert_chain(
    certfile='cert.pem',
    keyfile='key.pem'
)

# 定義處理程序來服務同目錄下的 index.html
class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.path = 'index.html'
        return http.server.SimpleHTTPRequestHandler.do_GET(self)

# 設定 HTTPS server
httpd = http.server.HTTPServer(
    (server_address, server_port),
    CustomHTTPRequestHandler,
    bind_and_activate=False
)

# 創建 socket 並套用 SSL
httpd.socket = socket.socket(address_family, socket.SOCK_STREAM)
httpd.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
httpd.socket = ssl_context.wrap_socket(
    httpd.socket,
    server_side=True
)

# 綁定並啟動 server
httpd.socket.bind((server_address, server_port))
httpd.server_activate()

def signal_handler(sig, frame):
    print('Shutting down server...')
    httpd.server_close()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

print(f"HTTPS Server started at https://{server_address}:{server_port}")
httpd.serve_forever()